﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoPrueba
{
    class Program
    {
        static void Main(string[] args)
        {
            /*1. Realizar un programa que lea por teclado dos números, si el primero es mayor al segundo informar su suma y diferencia, 
             en caso contrario informar el producto y la división del primero respecto al segundo.*/

            int num1, num2, suma, diferencia, producto, division;
            string num1Ing, num2Ing;

            Console.Write("Ingrese un numero: ");
            num1Ing = Console.ReadLine();
            num1 = int.Parse(num1Ing);

            Console.Write("Ingrese un numero: ");
            num2Ing = Console.ReadLine();
            num2 = int.Parse(num2Ing);

            if (num1 > num2) {
                suma = num1 + num2;
                diferencia = num1 - num2;
                Console.Write("La suma de ambos numeros es: ");
                Console.WriteLine(suma);
                Console.Write("La diferencia entre ambos numeros es de: ");
                Console.Write(diferencia);
            }
            else{
                producto = num1 * num2;
                division = num2 / num1;
                Console.Write("El producto de ambos numeros es: ");
                Console.WriteLine(producto);
                Console.Write("La division del primer numero con respecto al otro es: ");
                Console.Write(division);
            }


            Console.ReadKey();
        }
    }
}