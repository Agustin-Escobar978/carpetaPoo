﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoPrueba
{
    class Program
    {
        static void Main(string[] args)
        {
            /*2. Se ingresan seis notas de un alumno, si el promedio es mayor o igual a siete mostrar un mensaje "Promocionado"*/

            int nota1, nota2, nota3, nota4, nota5, nota6, promedio;
            string nota1Ing, nota2Ing, nota3Ing, nota4Ing, nota5Ing, nota6Ing;

            Console.Write("Ingrese la primera nota: ");
            nota1Ing = Console.ReadLine();
            nota1 = int.Parse(nota1Ing);

            Console.Write("Ingrese la segunda nota: ");
            nota2Ing = Console.ReadLine();
            nota2 = int.Parse(nota2Ing);

            Console.Write("Ingrese la tercera nota: ");
            nota3Ing = Console.ReadLine();
            nota3 = int.Parse(nota3Ing);

            Console.Write("Ingrese la cuarta nota: ");
            nota4Ing = Console.ReadLine();
            nota4 = int.Parse(nota4Ing);

            Console.Write("Ingrese la quinta nota: ");
            nota5Ing = Console.ReadLine();
            nota5 = int.Parse(nota5Ing);

            Console.Write("Ingrese la sexta nota: ");
            nota6Ing = Console.ReadLine();
            nota6 = int.Parse(nota6Ing);

            promedio = (nota1 + nota2 + nota3 + nota4 + nota5 + nota6) / 6;
            if (promedio >= 7)
            {
                Console.Write("Promocionado");
            }
            Console.ReadKey();
        }
    }
}
