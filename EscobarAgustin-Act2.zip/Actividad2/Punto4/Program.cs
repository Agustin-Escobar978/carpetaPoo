﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoPrueba
{
    class Program
    {
        static void Main(string[] args)
        {
            /*4. Se cargan por teclado tres números distintos. Mostrar por pantalla el mayor de ellos.*/

            int num1, num2, num3;
            string num1Ing, num2Ing, num3Ing;

            Console.Write("Ingrese un numero para compararlo con otros dos: ");
            num1Ing = Console.ReadLine();
            num1 = int.Parse(num1Ing);

            Console.Write("Ingrese un numero para compararlo con otros dos: ");
            num2Ing = Console.ReadLine();
            num2 = int.Parse(num2Ing);

            Console.Write("Ingrese un numero para compararlo con otros dos: ");
            num3Ing = Console.ReadLine();
            num3 = int.Parse(num3Ing);

            if (num1 > num2){
                if (num1 > num3)
                {
                    Console.WriteLine(num1);
                }
            }
            if (num2 > num1){
                    if (num2 > num3)
                    {
                        Console.WriteLine(num2);
                    }
            }
            if (num3 > num1){
                        if (num3 > num2)
                        {
                            Console.WriteLine(num3);
                        }
                    
            }

            Console.ReadKey();
        }
    }
}
