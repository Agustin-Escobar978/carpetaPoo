﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoPrueba
{
    class Program
    {
        static void Main(string[] args)
        {
            /*3. Se ingresa por teclado un número positivo de uno o dos dígitos (1..99) mostrar un mensaje indicando 
             si el número tiene uno o dos dígitos.(Tener en cuenta que condición debe cumplirse para tener dos dígitos, un número entero)*/

            int numero;
            string numeroIng;

            Console.Write("Ingrese un numero entre el 1 al 99: ");
            numeroIng = Console.ReadLine();
            numero = int.Parse(numeroIng);

            if (numero > 99)
            {
                Console.Write("Ingrese un numero entre el 1 al 99");
            }
            else {
                if (numero < 1) {
                    Console.Write("Ingrese un numero entre el 1 al 99");
                }
                else
                {
                    if (numero >= 10)
                    {
                        Console.Write("El numero tiene dos digitos");
                    }
                    else
                    {
                        if (numero > 0)
                        {
                            Console.Write("El numero tiene un digito");
                        }
                    }
                }
            }
            
            Console.ReadKey();
        }
    }
}
