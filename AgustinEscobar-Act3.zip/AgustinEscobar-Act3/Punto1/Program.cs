﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto1
{
    internal class Program
    {

        /*1. Realizar un programa que pida cargar una fecha cualquiera, luego verificar si dicha fecha corresponde a Navidad.*/
        static void Main(string[] args)
        {
            int dia, mes, diaNav, mesNav;
            string diaIng,  mesIng;

            Console.Write("Ingrese un mes en numero: ");
            mesIng = Console.ReadLine();
            mes = int.Parse(mesIng);

            Console.Write("Ingrese un dia en numero: ");
            diaIng = Console.ReadLine();
            dia = int.Parse(diaIng);

            diaNav = 25;
            mesNav = 12;

            if (mesNav == mes && diaNav == dia)
            {
                Console.WriteLine("El dia que ingresaste es navidad ¡Feliz navidad! ");
            }
            else
            {
                Console.WriteLine("El dia ingresado no corresponde a la fecha navideña D:");
            }

            Console.ReadKey();
        }
    }
}
