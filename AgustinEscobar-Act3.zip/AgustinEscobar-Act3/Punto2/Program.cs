﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto2
{
    internal class Program
    {

        /*2. Se ingresan tres valores por teclado, si todos son iguales se imprime la suma del primero con el
         segundo y a este resultado se lo multiplica por el tercero.*/
        static void Main(string[] args)
        {
            int num1, num2, num3, resultado;
            string num1Ing, num2Ing, num3Ing;

            Console.Write("Ingrese el primer numero: ");
            num1Ing = Console.ReadLine();
            num1 = int.Parse(num1Ing);

            Console.Write("Ingrese el segundo numero: ");
            num2Ing = Console.ReadLine();
            num2 = int.Parse(num2Ing);

            Console.Write("Ingrese el tercer numero: ");
            num3Ing = Console.ReadLine();
            num3 = int.Parse(num3Ing);

            if(num1 == num2 && num2 == num3)
            {
                resultado = num1 + num2;
                Console.WriteLine(resultado);
                resultado *= num3;
                Console.WriteLine(resultado);
            }
            else
            {
                Console.WriteLine("Pruebe ingresando el mismo valor en los tres numeros");
            }

            Console.ReadKey();
        }
    }
}
