﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto4
{
    internal class Program
    {

        /*4. Se ingresan por teclado tres números, si al menos uno de los valores ingresados es menor a 10, imprimir en 
         pantalla la leyenda "Alguno de los números es menor a diez".*/
        static void Main(string[] args)
        {
            int num1, num2, num3;
            string num1Ing, num2Ing, num3Ing;

            Console.Write("Ingrese el primer numero: ");
            num1Ing = Console.ReadLine();
            num1 = int.Parse(num1Ing);

            Console.Write("Ingrese el segundo numero: ");
            num2Ing = Console.ReadLine();
            num2 = int.Parse(num2Ing);

            Console.Write("Ingrese el tercer numero: ");
            num3Ing = Console.ReadLine();
            num3 = int.Parse(num3Ing);

            if (num1 < 10 || num2 < 10 || num3 < 10)
            {
                Console.WriteLine("Alguno de los números es menor a diez");
            }
            else
            {
                Console.WriteLine("Pruebe ingresando al menos un numero menor a 10");
            }
        }
    }
}
