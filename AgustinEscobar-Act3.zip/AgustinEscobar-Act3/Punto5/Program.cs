﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto5
{
    internal class Program
    {

        /*5. Escribir un programa que pida ingresar la coordenada de un punto en el plano, es decir dos valores enteros x e y 
        (distintos a cero).Posteriormente imprimir en pantalla en que cuadrante se ubica dicho punto. 
        (1º Cuadrante si x > 0 Y y > 0 , 2º Cuadrante: x < 0 Y y > 0). */
        static void Main(string[] args)
        {
            int valorX, valorY;
            string valorXIng, valorYIng;

            Console.WriteLine("Ingrese los valores de un punto para ver en que cuadrante esta:");
            Console.Write("x: ");
            valorXIng = Console.ReadLine();
            valorX = int.Parse(valorXIng);

            Console.Write("y: ");
            valorYIng = Console.ReadLine();
            valorY = int.Parse(valorYIng);

            if(valorX > 0 && valorY > 0)
            {
                Console.Write("El punto se encuentra en el primer cuadrante");
            }else
            {
                if (valorX < 0 && valorY > 0)
                {
                    Console.Write("El punto se encuentra en el segundo cuadrante");
                }
                else
                {
                    if (valorX < 0 && valorY < 0)
                    {
                        Console.Write("El punto se encuentra en el tercer cuadrante");
                    }
                    else
                    {
                        if (valorX > 0 && valorY < 0)
                        {
                            Console.Write("El punto se encuentra en el cuarto cuadrante");
                        }
                    }
                }
            }
        }
    }
}
