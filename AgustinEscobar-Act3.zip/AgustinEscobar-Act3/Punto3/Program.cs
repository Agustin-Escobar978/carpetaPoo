﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto3
{
    internal class Program
    {

        /*3. Se ingresan por teclado tres números, si todos los valores ingresados son menores a 10, imprimir en pantalla 
         la leyenda "Todos los números son menores a diez"*/
        static void Main(string[] args)
        {
            int num1, num2, num3;
            string num1Ing, num2Ing, num3Ing;

            Console.Write("Ingrese el primer numero: ");
            num1Ing = Console.ReadLine();
            num1 = int.Parse(num1Ing);

            Console.Write("Ingrese el segundo numero: ");
            num2Ing = Console.ReadLine();
            num2 = int.Parse(num2Ing);

            Console.Write("Ingrese el tercer numero: ");
            num3Ing = Console.ReadLine();
            num3 = int.Parse(num3Ing);

            if (num1 < 10 && num2 < 10 && num3 < 10)
            {
                Console.WriteLine("Todos los números son menores a diez");
            }
            else
            {
                Console.WriteLine("Pruebe ingresando numeros menores a 10");
            }
            Console.ReadKey();
        }
    }
}
