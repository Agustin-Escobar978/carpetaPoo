﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoPrueba
{
    class Program
    {
        static void Main(string[] args)
        {
            /*6. Escribir un programa que lea el peso (en kilogramos) y la altura (en metros) de una persona, y mostrar 
            por pantalla su índice de masa corporal (IMC) (El IMC se calcula dividiendo el peso entre el cuadrado de la altura).*/

            double peso, altura, IMC;
            string pesoIng, alturaIng;

            Console.Write("Ingresa su peso en kilogramos: ");
            pesoIng = Console.ReadLine();
            peso = double.Parse(pesoIng);

            Console.Write("Ingresa su altura en metros: ");
            alturaIng = Console.ReadLine();
            altura = double.Parse(alturaIng);

            Console.WriteLine(peso);
            Console.WriteLine(altura);

            IMC = peso / (altura * altura);

            Console.Write("Su IMC es: ");
            Console.WriteLine(IMC);

            Console.ReadKey();
        }
    }
}