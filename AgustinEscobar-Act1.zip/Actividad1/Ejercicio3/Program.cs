﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoPrueba
{
    class Program
    {
        static void Main(string[] args)
        {
            /*3. Realizar un programa que lea cuatro valores numéricos e informar su suma y promedio.*/

            int num1, num2, num3, num4, suma, promedio;
            string numIng;

            Console.Write("Ingrese un numero para sumar y calcular el promedio: ");
            numIng = Console.ReadLine();
            num1 = int.Parse(numIng);

            Console.Write("Ingrese un numero para sumar y calcular el promedio: ");
            numIng = Console.ReadLine();
            num2 = int.Parse(numIng);

            Console.Write("Ingrese un numero para sumar y calcular el promedio: ");
            numIng = Console.ReadLine();
            num3 = int.Parse(numIng);

            Console.Write("Ingrese un numero para sumar y calcular el promedio: ");
            numIng = Console.ReadLine();
            num4 = int.Parse(numIng);

            suma = num1 + num2 + num3 + num4;
            promedio = suma / 4;

            Console.Write("La suma es igual a: ");
            Console.WriteLine(suma);
            Console.Write("El promedio es igual: ");
            Console.WriteLine(promedio);


            Console.ReadKey();
        }
    }
}