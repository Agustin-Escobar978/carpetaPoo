﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoPrueba
{
    class Program
    {
        static void Main(string[] args)
        {
            /*2. Escribir un programa en el cual se ingresen cuatro números, calcular e
             informar la suma de los dos primeros y el producto del tercero y el cuarto.*/

            int num1, num2, num3, num4, suma, producto;
            string numIng;

            Console.Write("Ingrese un numero para sumar: ");
            numIng= Console.ReadLine();
            num1 = int.Parse(numIng);

            Console.Write("Ingrese un numero para sumar: ");
            numIng = Console.ReadLine();
            num2 = int.Parse(numIng);

            Console.Write("Ingrese un numero para obtener el producto: ");
            numIng = Console.ReadLine();
            num3 = int.Parse(numIng);

            Console.Write("Ingrese un numero para obtener el producto: ");
            numIng = Console.ReadLine();
            num4 = int.Parse(numIng);

            suma = num1 + num2;
            producto = num3 * num4;

            Console.Write("La suma es igual a: ");
            Console.WriteLine(suma);
            Console.Write("El producto es igual: ");
            Console.WriteLine(producto);


            Console.ReadKey();
        }
    }
}