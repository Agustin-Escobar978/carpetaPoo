﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoPrueba
{
    class Program
    {
        static void Main(string[] args)
        {
            /*5. Realizar la carga del radio de un círculo, mostrar por pantalla la circunferencia y el área del mismo (La circunferencia 
             se calcula multiplicando el doble del radio por π (pi), y el área se calcula multiplicando π por el cuadrado del radio).*/

            int radio;
            double circuferencia, area;
            string radioIng;

            Console.Write("Ingresa el radio de un circulo para calcular su circunferencia y area: ");
            radioIng = Console.ReadLine();
            radio = int.Parse(radioIng);

            circuferencia = 3.14 * (radio * 2);
            area = 3.14 * (radio * radio);

            Console.Write("La circuferencia es: ");
            Console.WriteLine(circuferencia);
            Console.Write("El area es: ");
            Console.WriteLine(area);

            Console.ReadKey();
        }
    }
}