﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoPrueba
{
    class Program
    {
        static void Main(string[] args)
        {
            /*4. Se debe desarrollar un programa que pida el ingreso del precio de un artículo y la 
            cantidad que lleva el cliente. Mostrar lo que debe abonar el comprador.*/

            int precio, cantidad, total;
            string precioIng, cantidadIng;

            Console.Write("Ingresa el precio del articulo: ");
            precioIng = Console.ReadLine();
            precio = int.Parse(precioIng);

            Console.Write("Ingresa la cantidad que lleva: ");
            cantidadIng = Console.ReadLine();
            cantidad = int.Parse(cantidadIng);

            total = precio * cantidad;

            Console.Write("El total a pagar es: ");
            Console.WriteLine(total);

            Console.ReadKey();
        }
    }
}