﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoPrueba
{
    class Program
    {
        static void Main(string[] args)
        {
            /*1.Realizar la carga del lado de un cuadrado, mostrar 
            por pantalla el perímetro del mismo(El perímetro de un cuadrado se calcula multiplicando el valor del lado por cuatro).*/

            int lado, perimetro;
            string ladoIng;

            Console.Write("Ingrese el lado de un cuadrado para calcular su perímetro: ");
            ladoIng = Console.ReadLine();
            lado = int.Parse(ladoIng);
            perimetro = lado * 4;

            Console.Write("El perimetro del cuadrado es: ");
            Console.WriteLine(perimetro);


            Console.ReadKey();
        }
    }
}